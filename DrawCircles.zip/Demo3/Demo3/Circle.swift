//
//  Circle.swift
//  Demo3
//
//  Created by Gauri Kulkarni on 10/19/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit

class Circle {
    var startPoint: CGPoint
    var endPoint: CGPoint
    var radius:CGFloat
    var color : CGColor
    var velX:CGFloat
    var velY:CGFloat
    
    init(startPoint:CGPoint,endPoint:CGPoint,radius:CGFloat,color:CGColor,velX:CGFloat,velY:CGFloat) {
        self.startPoint = startPoint
        self.endPoint = endPoint
        self.radius = radius
        self.color = color
        self.velX = velX
        self.velY = velY
    }
    

}


