//
//  DrawView.swift
//  Demo3
//
//  Created by Gauri Kulkarni on 10/19/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit



class DrawView : UIView{
    
    var isDrawing = false
   // var lastPoint: CGPoint!
    var color: CGColor = UIColor.black.cgColor
    var circles = [Circle]()
    var dummycircle = [Circle]()
    var moveCircle = [Circle]()
    var xDist:CGFloat!
    var x1:CGFloat = CGFloat()
    var x2:CGFloat = CGFloat()
    var y1:CGFloat = CGFloat()
    var y2:CGFloat = CGFloat()
    var r1:CGFloat = CGFloat()
    var radius:CGFloat = CGFloat()
    var currentPoint:CGPoint = CGPoint()
    var firstTouch:CGPoint = CGPoint()
    //var maintainCount = 0
    var timeFirst:TimeInterval = TimeInterval()
    var timeLast:TimeInterval = TimeInterval()
    var moveTouchBegan:CGPoint = CGPoint()
    var moveTouchEnd:CGPoint = CGPoint()
    
    var moveTouchBX:CGFloat = CGFloat()
    var moveTouchBY:CGFloat = CGFloat()
    var moveTouchEX:CGFloat = CGFloat()
    var moveTouchEY:CGFloat = CGFloat()
    
    var speedX:CGFloat = CGFloat()
    var speedY:CGFloat = CGFloat()
    var newX:CGFloat = CGFloat()
    var newY:CGFloat = CGFloat()
    
    var screenSize:CGRect = CGRect()
    var screenHight:CGFloat = CGFloat()
    var screenWidth:CGFloat = CGFloat()
    
    var canvasUpperH:CGFloat = CGFloat()
    var canvasLeftW:CGFloat = CGFloat()
    var canvasLowerH:CGFloat = CGFloat()
    var canvasRightW:CGFloat = CGFloat()
    var minimumValue:[CGFloat] = [CGFloat]()
    var minimumOf:CGFloat = CGFloat()
    
    var mode:Int = 1
    
    func drawmode(){
        stopTimer()
        mode = 1
    }
    func deletemode(){
        stopTimer()
        mode = 2
    }
    func movemode(){
        stopTimer()
        mode = 3
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !isDrawing else{
            return
        }
        isDrawing = true
        guard let touch = touches.first else {
            return
        }
        if mode == 1 {
            firstTouch = touch.location(in: self)
            x1 = firstTouch.x
            y1 = firstTouch.y
            
            screenSize =  UIScreen.main.bounds
            screenHight = screenSize.height
            screenWidth = screenSize.width
            //screenHight = screenHight - 50.0
            canvasUpperH = firstTouch.y
            canvasLeftW = firstTouch.x
            canvasLowerH = CGFloat(screenHight - firstTouch.y - 230.0)
            canvasRightW = CGFloat(screenWidth - firstTouch.x)
            
            minimumValue = [canvasRightW,canvasLowerH,canvasLeftW,canvasUpperH]
            minimumOf = minimumValue.min()!
            //print(minimumOf)
           //print("width and hight rw \(canvasRightW) LH \(canvasLowerH) UH \(canvasUpperH) LW \(canvasLeftW)")
            
            setNeedsDisplay()
        }
        if mode == 2{
            currentPoint = touch.location(in: self)
            let cx = currentPoint.x
            let cy = currentPoint.y
            let currentIndex = 0
          
            for (k,v) in circles.enumerated().reversed() {
                //maintainCount = circles.count
                let circlePoints = v.startPoint
                let circleX = circlePoints.x
                let circleY = circlePoints.y
                let circleR = v.radius
                
                let distx = CGFloat(cx - circleX) * CGFloat(cx - circleX)
                let disty = CGFloat(cy - circleY) * CGFloat(cy - circleY)
                let distance = CGFloat(sqrt(distx + disty))
                if distance <= circleR {
                    if(k > -1){
                        circles.remove(at : k)
                       // print(circles.count)
                   }
                                        
                }
            }
            setNeedsDisplay()
        }
        if mode == 3{
            moveTouchBegan = touch.location(in: self)
            timeFirst = touch.timestamp
            moveTouchBX = moveTouchBegan.x
            moveTouchBY = moveTouchBegan.y
            
        }
       
    }
    
   override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard isDrawing else {
            return
        }
        guard let touch = touches.first else {
            return
        }
        if mode == 1 {
            currentPoint = touch.location(in: self)
            
            x2 = currentPoint.x // current touch
            y2 = currentPoint.y // current touch
            
            let x = CGFloat(x1 - x2) * CGFloat(x1 - x2)
            let y = CGFloat(y1 - y2) * CGFloat(y1 - y2)
            
            r1 = CGFloat(sqrt(x + y))
            // add circle in dummycircle array which will show increasing circle on touchmove
            
            if r1 >= minimumOf{
                
                r1 = minimumOf
            }
            
            dummycircle.removeAll()
            let circle = Circle(startPoint: firstTouch, endPoint: currentPoint, radius: r1, color: color, velX : 0.0, velY: 0.0)
            dummycircle.append(circle)
            setNeedsDisplay()
        }
        //print("mode value else")
        if mode == 3{
            
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard isDrawing else{
            return
        }
        isDrawing = false
        guard let touch = touches.first else {
            return
        }
        if mode == 1{
            currentPoint = touch.location(in: self)
            let endX = currentPoint.x
            let endY = currentPoint.y
            var diffX:CGFloat!
            var diffY:CGFloat!
            
            if endX == x1 || endY == y1{
                diffX = 10.0
                diffY = 10.0
                
            }
            else{
                diffX = CGFloat(endX - x1)
                diffY = CGFloat(endY - y1)
            }
            //calculate radius on basis of touch points
            radius = CGFloat(sqrt((diffX * diffX) + (diffY * diffY)))
            
            // restriction on radius
            if radius >= minimumOf{
                
                radius = minimumOf - 2.0
            }
           
            // add new circle in array
            let circle = Circle(startPoint: firstTouch, endPoint: currentPoint, radius: radius, color: color, velX : 0.0, velY: 0.0)
            circles.append(circle)
            
            dummycircle.removeAll()
            diffX = 0.0
            diffY = 0.0
            setNeedsDisplay()
        }
        if mode == 3{
            moveTouchEnd = touch.location(in: self)
            
            timeLast = touch.timestamp
            let timeStamp = Double(timeLast) - Double(timeFirst)
            
            moveTouchEX = moveTouchEnd.x
            moveTouchEY = moveTouchEnd.y
            
            let valueX = CGFloat(moveTouchEX - moveTouchBX)
            let valueY = CGFloat(moveTouchEY - moveTouchBY)
            
            speedX = CGFloat(valueX) / CGFloat(timeStamp)
            speedY = CGFloat(valueY) / CGFloat(timeStamp)

            speedX = speedX / CGFloat(100.0)
            speedY = speedY / CGFloat(100.0)
    
            for circle in circles {
                
            
            let circleStart = circle.startPoint
                  
            let mx = CGFloat(circleStart.x - moveTouchBX) * CGFloat(circleStart.x - moveTouchBX)
            let my = CGFloat(circleStart.y - moveTouchBY) * CGFloat(circleStart.y - moveTouchBY)
            let distanceFromCenter = CGFloat(sqrt(mx + my))
                 
            if((circle.radius) >= distanceFromCenter){
                
                circle.velX = speedX
                circle.velY = speedY
               
                }

             }
            
            setNeedsDisplay()
        }
    }
    
    override func draw(_ rect: CGRect) {
        
        let context = UIGraphicsGetCurrentContext()
        for circle in dummycircle{
            context?.beginPath()
            context?.setStrokeColor(circle.color)
            context?.addArc(center: circle.startPoint, radius: circle.radius, startAngle: 0.0, endAngle: .pi * 2.0, clockwise: true)
            
            context?.strokePath()
        }
        for circle in circles{
            context?.beginPath()
            context?.setStrokeColor(circle.color)
            context?.addArc(center: circle.startPoint, radius: circle.radius, startAngle: 0.0, endAngle: .pi * 2.0, clockwise: true)
            
            context?.strokePath()
        }
        
        if mode == 3{

            startTimer()
          
            setNeedsDisplay()
            
        }
    }
    
    var timeTest : Timer?
    func startTimer()
    {
        guard timeTest == nil else {return}
        timeTest = Timer.scheduledTimer(withTimeInterval: 0.01,
                  repeats: true,
                  block: {_ in self.move()})
    }
    
    func stopTimer()
    {
        timeTest?.invalidate()
        timeTest = nil
        for circle in circles {
            circle.velX = 0.0
            circle.velY = 0.0
        }
    }
    
    
    func move(){
        
        for circle in circles{
          
            let xbound = CGFloat(circle.startPoint.x - circle.radius)
            let yboundU = CGFloat(circle.startPoint.y - circle.radius)
            let xboundW = CGFloat(circle.startPoint.x + circle.radius)
            let yboundL = CGFloat(circle.startPoint.y + circle.radius + 230.0)
                                      
     
            if  xboundW >= screenWidth || xbound <= 0{
                circle.velX = CGFloat(circle.velX * (-1))
                
            }
            if yboundL >= screenHight || yboundU  <= 0{
                circle.velY = CGFloat(circle.velY * (-1))
               
            }
           
            circle.startPoint.x += circle.velX
            circle.startPoint.y += circle.velY
            
        }
     
        setNeedsDisplay()
        
    }
    
}
 


