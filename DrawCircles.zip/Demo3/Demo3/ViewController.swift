//
//  ViewController.swift
//  Demo3
//
//  Created by Gauri Kulkarni on 10/19/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var drawView: DrawView!
    @IBOutlet weak var Currentmode: UILabel!
    
    @IBOutlet var ColorButtons: [UIButton]!
    
    
    @IBAction func btnDrawMode(_ sender: Any) {
        ColorButtons.forEach{(Button) in
            UIView.animate(withDuration: 0.3, animations: {
            Button.isHidden = !Button.isHidden
            self.view.layoutIfNeeded()
           })
        }
    }
    
    @IBAction func btnBlackColor(_ sender: Any) {
        drawView.color = UIColor.black.cgColor
        drawView.drawmode()
        Currentmode.text = "Drawing Black Circle"
    }
    @IBAction func btnGreenMode(_ sender: Any) {
        drawView.drawmode()
        drawView.color = UIColor.green.cgColor
        Currentmode.text = "Drawing Green Circle"
    }
    
    @IBAction func btnBlueColor(_ sender: Any) {
        drawView.drawmode()
        drawView.color = UIColor.blue.cgColor
        Currentmode.text = "Drawing Blue Circle"
    }
    @IBAction func btnRedColor(_ sender: Any) {
        drawView.drawmode()
        drawView.color = UIColor.red.cgColor
        Currentmode.text = "Drawing Red Circle"
    }
    
    @IBAction func btnDeleteMode(_ sender: Any) {
        drawView.deletemode()
        Currentmode.text = "Delete Circle"
    }
    
    @IBAction func btnMoveMode(_ sender: Any) {
        drawView.movemode()
        Currentmode.text = "Move Circle"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


}

